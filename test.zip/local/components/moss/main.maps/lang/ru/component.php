<?
$MESS ['T_NEWS_NEWS_NA'] = "Раздел не найден.";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Модуль Информационных блоков не установлен";
?>