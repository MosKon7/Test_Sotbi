<?
$MESS ['T_TITLE'] = "Moss";
$MESS ['T_DESC'] = "Moss: Карта";
$MESS ['T_NAME'] = "Карта";
?>