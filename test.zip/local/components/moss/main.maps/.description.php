<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("T_NAME"),
	"DESCRIPTION" => GetMessage("T_DESC"),
	"CACHE_PATH" => "Y",
	"PATH" => array(
         "ID" => "moss",
         "NAME" => GetMessage("T_TITLE")
	),
);

?>